import os, uuid, uvicorn
from fastapi import FastAPI, UploadFile, File, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import socketio

sio = socketio.AsyncServer(async_mode='asgi', cors_allowed_origins='*')
app = FastAPI()
socket_app = socketio.ASGIApp(sio, app)

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")
os.makedirs("static/uploads", exist_ok=True)

@app.get("/")
async def s1(request: Request):
    photos = [p for p in os.listdir("static/uploads") if p.endswith(('jpg','png'))]
    return templates.TemplateResponse("1_standby.html", {"request": request, "photos": photos})

@app.get("/layout")
async def s2(request: Request): return templates.TemplateResponse("2_layout.html", {"request": request})

@app.get("/camera")
async def s3(request: Request): return templates.TemplateResponse("3_camera.html", {"request": request})

@app.get("/processing")
async def s4(request: Request): return templates.TemplateResponse("4_processing.html", {"request": request})

@app.get("/download")
async def s5(request: Request): return templates.TemplateResponse("5_download.html", {"request": request})

@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    fname = f"{uuid.uuid4().hex}.jpg"
    path = f"static/uploads/{fname}"
    with open(path, "wb") as f: f.write(await file.read())
    await sio.emit('update_mosaic', {'url': f'/static/uploads/{fname}'})
    return {"url": f"/static/uploads/{fname}"}

if __name__ == "__main__":
    uvicorn.run(socket_app, host="0.0.0.0", port=8000)